#!/usr/bin/perl -w

################################################################
# closecomments.pl v1.0 by Matt Berther (www.mattberther.com)  #
#                                                              #
# This script is based on Kevin Schumacher (www.geeksblog.com) #
# PHP script that does the same thing. Only difference is that #
# this script can always be launched directly from crontab,    #
# rather than needing to use lynx to call.                     #
################################################################

use DBI;
use strict;

# Your MovableType database
my $database = "";

# The user to access this database
my $dbuser = "";

# The password used to access this database
my $dbpass = "";

# The hostname to connect to - most likely this will be localhost
my $dbhost = "localhost";

# if you changed the name of the MT entry table, change this value to reflect
my $entryTableName = "mt_entry";

# Number of days to keep comments open
my $closeDays = 7;

################################################################
# DO NOT EDIT BELOW THIS LINE UNLESS YOU KNOW WHAT YOURE DOING #
################################################################

my $dbh = DBI->connect("DBI:mysql:$database:$dbhost", $dbuser, $dbpass)
    || die "Unable to connect to MovableType database: $DBI::errstr\n";

my $time = $closeDays * (24*60*60);
my @closeTime = localtime(time - $time);

my $closeDate = sprintf("%d-%d-%d %d:%d:%d",
    $closeTime[5] + 1900,
    $closeTime[4] + 1,
    $closeTime[3], $closeTime[2], $closeTime[1], $closeTime[0]);

my $sql = qq{ UPDATE $entryTableName SET entry_allow_comments = 2 WHERE entry_created_on < '$closeDate' };
my $sth = $dbh->prepare($sql);
$sth->execute();

$dbh->disconnect;

exit;


using System;

namespace [!output SAFE_NAMESPACE_NAME]
{
	public interface [!output SAFE_CLASS_NAME]
	{
	}
}

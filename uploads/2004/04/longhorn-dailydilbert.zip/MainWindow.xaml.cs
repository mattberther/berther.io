using System;
using System.IO;
using System.Net;
using System.Text.RegularExpressions;

using MSAvalon.Windows;
using MSAvalon.Windows.Controls;
using MSAvalon.Windows.Media;

namespace MattBerther.DailyDilbert
{
	public partial class MainWindow : Window
	{
		private const string BASE_ADDRESS = "http://www.dilbert.com/comics/dilbert/archive/";
		
		private void WindowLoaded(object sender, EventArgs e)
		{
			ImageData imageData = ImageData.Create(GetDailyImageUrl());
			dilbertImage.Source = imageData;			
			this.ContentSize = new Size(imageData.Width, imageData.Height);
		}
		
		private string GetDailyImageUrl()
		{
			string streamText = "";
			WebClient client = new WebClient();
			
			using (StreamReader rdr = new StreamReader(client.OpenRead(BASE_ADDRESS)))
			{
				streamText = rdr.ReadToEnd();
			}
			
			Match match = Regex.Match(streamText, @"/comics/dilbert/archive/images/(\w+).gif",
				RegexOptions.IgnoreCase);
			
			if (match != Match.Empty)
			{
				return "http://www.dilbert.com/" + match.Value;
			}
			
			return "";
		}		
	}
}

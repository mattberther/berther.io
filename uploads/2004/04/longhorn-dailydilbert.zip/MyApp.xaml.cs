using System;
using MSAvalon.Windows;
using MSAvalon.Windows.Navigation;

namespace MattBerther.DailyDilbert
{
	public partial class MyApp : Application
	{
		private void AppStartingUp(object sender, StartingUpCancelEventArgs e)
		{
			Window mainWindow = new MainWindow();
			mainWindow.Show();
		}
	}
}	
		